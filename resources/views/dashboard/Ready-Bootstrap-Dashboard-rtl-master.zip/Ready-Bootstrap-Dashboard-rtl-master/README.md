# Ready-Bootstrap-Dashboard-rtl

# Ready-Bootstrap تعريب لوحة تحكم 

![Alt text](assets/img/img.png?raw=true "Title")


thanks http://www.themekita.com/ready-bootstrap-dashboard.html

